let user = {
  name: "rukhi",
  age: 16,
  email: "rukhi@gmail.com"
};
function show(user) {
  console.log(`name: ${user.name}, age: ${user.age}, e-mail: ${user.email}`);
}
show(user);


let products = {
  laptop: 1200,
  mouse: 150,
  keyboard: 300,
  monitor: 800,
};

function expensive(products) {
  for (let product in products) {
    if (products[product] > 350) {
      console.log(product + ":" + products[product]);
    }
  }
}
expensive(products)


let car = {
  brand: "Toyota",
  model: "Corolla",
  year: 2020
};

function info(car) {
  return `Год выпуска ${car.year}, Модель ${car.brand} ${car.model}`;
}

console.log(info(car));


function isEven(number) {
  return number % 2 === 0;
}
console.log(isEven(4));
console.log(isEven(7));  


function sumArray(numbers) {
  let sum = 0;
  for (let i = 0; i < numbers.length; i++) {
    sum = sum + numbers[i];
  }
  return sum;
}
console.log(sumArray([1, 2, 3, 4, 5]));


const multiply = (a, b) => a * b;
console.log(multiply(3, 4));
