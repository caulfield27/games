let movies = ["moana", "mulan", "frozen", "lady bug", "foxy"]
console.log(movies)
console.log(movies[1])
console.log(movies[4])
movies.push("forest gamp");
console.log(movies)
movies.shift()
console.log(movies)
movies[2] = "matrica";
console.log(movies);
console.log(movies.length)

let numbers = [1,2,3,4,5];
console.log(numbers)
let updateNumbers = numbers.map((elem) => elem + 2);
console.log(updateNumbers)

let names = ["rukhi", "sophie", "sam", "karim", "makhvash", "jannat"];
names.sort();
console.log(names)


let interstellar = movies.includes("interstellar");
console.log(interstellar);


for (let i = 0; i < movies.length; i++) {
    console.log(movies[i])
}


movies.forEach((movie) => {
    console.log(movie);
});


let ratings = [5, 4, 3, 5, 4, 5]; 
let rating = movies.map((movie, index) => {
  return {
    name: movie,
    rating: ratings[index]
  };
});
console.log(rating);

let topRatedMovies = rating.filter(movie => movie.rating > 4);
console.log(topRatedMovies);

let person = {
  name: "rukhi",
  age: 16,
  city: "dushanbe"
};
console.log(person);
console.log(person.name)

person.hobby = "programming"
console.log(person);

person.age = 30;
console.log(person);

delete person.city;
console.log(person);

let car = {
    brand: "Mersedes",
    model: "AVTR",
    year: 2020,
}
console.log(car.model);
console.log("year" in car);


let book = {
  title: "hunger games",
  author: "Suzanne Collins",
  year: 2008,
  pages: 400
};

console.log(Object.keys(book));
console.log(Object.values(book));

let students = [
  { name: "rukhi", grade: 92 },
  { name: "sam", grade: 91 },
  { name: "sophie", grade: 87 },
  { name: "jannat", grade: 60 },
  { name: "karim", grade: 47 }
];

let topStudents = students.filter(student => student.grade > 90);

console.log(topStudents);
